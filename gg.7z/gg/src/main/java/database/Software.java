package database;

import java.util.Date;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

@DatabaseTable(tableName = "software")
public class Software {

    @DatabaseField(columnName = "productId", id = true)
    private int productId;

    @DatabaseField(columnName = "designation")
    private String designation;

    @DatabaseField(columnName = "price")
    private double price;

    @DatabaseField(columnName = "saleInPercent")
    private double saleInPercent;
    
    @DatabaseField(columnName = "genre")
    private String genre;
    
    @DatabaseField(columnName = "rating")
    private double rating;
    
    @DatabaseField(columnName = "picPath")
    private String picPath;
    

    @DatabaseField(columnName = "releaseDate")
    private Date releaseDate;
    
    @DatabaseField(columnName = "fsk")
    private int fsk;

	public Software() {
		
	}

	public Software(int productId, String designation, double price, double saleInPercent, String genre, double rating,
			String picPath, Date releaseDate, int fsk) {
		this.productId = productId;
		this.designation = designation;
		this.price = price;
		this.saleInPercent = saleInPercent;
		this.genre = genre;
		this.rating = rating;
		this.picPath = picPath;
		this.releaseDate = releaseDate;
		this.fsk = fsk;
	}

	
	public Software(String designation, double price, double saleInPercent, String genre, double rating, String picPath,
			Date releaseDate, int fsk) {
		this.designation = designation;
		this.price = price;
		this.saleInPercent = saleInPercent;
		this.genre = genre;
		this.rating = rating;
		this.picPath = picPath;
		this.releaseDate = releaseDate;
		this.fsk = fsk;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public double getSaleInPercent() {
		return saleInPercent;
	}

	public void setSaleInPercent(double saleInPercent) {
		this.saleInPercent = saleInPercent;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	public double getRating() {
		return rating;
	}

	public void setRating(double rating) {
		this.rating = rating;
	}

	public String getPicPath() {
		return picPath;
	}

	public void setPicPath(String picPath) {
		this.picPath = picPath;
	}

	public Date getReleaseDate() {
		return releaseDate;
	}

	public void setReleaseDate(Date releaseDate) {
		this.releaseDate = releaseDate;
	}

	public int getFsk() {
		return fsk;
	}

	public void setFsk(int fsk) {
		this.fsk = fsk;
	}

	
    
   

    
}
