package gg;

import static spark.Spark.get;
import static spark.Spark.post;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import com.google.gson.Gson;
import com.j256.ormlite.dao.Dao;
import com.j256.ormlite.dao.DaoManager;
import com.j256.ormlite.jdbc.JdbcConnectionSource;
import com.j256.ormlite.support.ConnectionSource;

import database.*;

public class Main {

	public static void main(String[] args) throws SQLException {

		String databaseUrl = "jdbc:mariadb://localhost:3306/ggDB";
		ConnectionSource connectionSource = new JdbcConnectionSource(databaseUrl);
		((JdbcConnectionSource) connectionSource).setUsername("root");
		((JdbcConnectionSource) connectionSource).setPassword("root");
		Dao<UserGG, String> userDao = DaoManager.createDao(connectionSource, UserGG.class);
		Dao<Software, String> softwareDao = DaoManager.createDao(connectionSource, Software.class);
		Dao<Hardware, String> hardwareDao = DaoManager.createDao(connectionSource, Hardware.class);
		
//		POST routen
		post("/userLogin", (req, res) -> {
			System.out.println("Route: userLogin activated");
			Gson gson = new Gson();
			List<UserGG> usersRe = new ArrayList<UserGG>();
			String email = req.queryParams("email");
			String password = req.queryParams("password");
			List<UserGG> users = userDao.queryForAll();
			for (UserGG u : users) {
				if (u.getEmail().equals(email)) {
					if (u.getPassword().equals(password)) {
						usersRe.add(u);
						return gson.toJson(usersRe);
					} else
						return null;
				}
			}
			return null;
		}); // end of UserLogin
		
		
		post("/register", (req, res) -> {
			System.out.println("Route: register activated");
			Gson gson = new Gson();
			String userName = req.queryParams("userName");
	        String password = req.queryParams("password");
	        String email = req.queryParams("email");
	        Date bday = new SimpleDateFormat("yyyy.MM.dd").parse(req.queryParams("bday"));
	        String street = req.queryParams("street");
	        int pcode = Integer.parseInt(req.queryParams("pcode"));
	        String city = req.queryParams("city");
			UserGG user = new UserGG(userName,password,email,bday,street,pcode,city);
			List<UserGG> users = userDao.queryForAll();
			int counter = 0;
			for (UserGG u : users) {
				if (u.getUserId()> counter) {
					counter = u.getUserId();
				}
			}
			counter++;
			user.setUserId(counter);
			userDao.createIfNotExists(user);
			users.clear();
			users.add(user);
			return gson.toJson(users);
		}); // end of register
		
		
		post("/addProduct", (req, res) -> {
			System.out.println("Route: addProduct activated");
			Gson gson = new Gson();
			String designation = req.queryParams("designation");
			double price = Double.parseDouble(req.queryParams("price"));
			double saleInPercent = Double.parseDouble(req.queryParams("saleInPercent"));
			double rating = Double.parseDouble(req.queryParams("rating"));
			String picPath = req.queryParams("picPath");
			Date releaseDate = new SimpleDateFormat("yyyy.MM.dd").parse(req.queryParams("releaseDate"));
			if(req.queryParams("type") != null) {
				String type = req.queryParams("type");
				String manufacturer = req.queryParams("manufacturer");
				Hardware hardware = new Hardware(designation,price,saleInPercent,type,rating,picPath,releaseDate,manufacturer);
				List<Hardware> hardwares = hardwareDao.queryForAll();
				int counter = 0;
				for (Hardware h : hardwares) {
					if (h.getProductId()> counter) {
						counter = h.getProductId();
					}
				}
				counter++;
				hardware.setProductId(counter);
				hardwares.clear();
				hardwareDao.createIfNotExists(hardware);
				hardwares.add(hardware);
				return gson.toJson(hardwares);
				
			}
			else {
				String genre = req.queryParams("genre");
				int fsk = Integer.parseInt(req.queryParams("fsk"));
				Software Software = new Software(designation,price,saleInPercent,genre,rating,picPath,releaseDate,fsk);
				List<Software> Softwares = softwareDao.queryForAll();
				int counter = 0;
				for (Software s : Softwares) {
					if (s.getProductId()> counter) {
						counter = s.getProductId();
					}
				}
				counter++;
				Software.setProductId(counter);
				Softwares.clear();
				softwareDao.createIfNotExists(Software);
				Softwares.add(Software);
				return gson.toJson(Softwares);
			}
		}); // end of addProduct
		
		
		
		post("/updateProduct", (req, res) -> {
			System.out.println("Route: updateProduct activated");
			Gson gson = new Gson();
			int productId = Integer.parseInt(req.queryParams("productId"));
			String designation = req.queryParams("designation");
			double price = Double.parseDouble(req.queryParams("price"));
			double saleInPercent = Double.parseDouble(req.queryParams("saleInPercent"));
			double rating = Double.parseDouble(req.queryParams("rating"));
			String picPath = req.queryParams("picPath");
			Date releaseDate = new SimpleDateFormat("yyyy.MM.dd").parse(req.queryParams("releaseDate"));
			if(req.queryParams("type") != null) {
				String type = req.queryParams("type");
				String manufacturer = req.queryParams("manufacturer");
				Hardware hardware = new Hardware(productId,designation,price,saleInPercent,type,rating,picPath,releaseDate,manufacturer);
				List<Hardware> hardwares = new ArrayList<>();
				hardwareDao.update(hardware);
				hardwares.add(hardware);
				return gson.toJson(hardwares);
				
			}
			else {
				String genre = req.queryParams("genre");
				int fsk = Integer.parseInt(req.queryParams("fsk"));
				Software Software = new Software(productId,designation,price,saleInPercent,genre,rating,picPath,releaseDate,fsk);
				List<Software> softwares = new ArrayList<>();
				softwareDao.update(Software);
				softwares.add(Software);
				return gson.toJson(softwares);
			}
		}); // end of updateProduct
		
		post("/deleteProduct", (req, res) -> {
			Gson gson = new Gson();
			List<String> response = new ArrayList<>();
			if(req.queryParams("type") != null) {
				hardwareDao.deleteById(req.queryParams("productId"));
				if (hardwareDao.queryForId(req.queryParams("productId"))!=null) {
					response.add("True");
				}
				else
					response.add("False");
			}
			else {
				softwareDao.deleteById(req.queryParams("productId"));
			}
				
			return gson.toJson(response);
		}); // end of deleteProduct
			
		
		post("/updateUser", (req, res) -> {
				System.out.println("Route: updateUser activated");
		    	Gson gson = new Gson();
		    	int userId = Integer.parseInt(req.queryParams("userId"));
		        String userName = req.queryParams("userName");
		        String role = req.queryParams("role");
		        String password = req.queryParams("password");
		        String email = req.queryParams("email");
		        Date bday = new SimpleDateFormat("yyyy.MM.dd").parse(req.queryParams("bday"));
		        String street = req.queryParams("street");
		        int pcode = Integer.parseInt(req.queryParams("pcode"));
		        String city = req.queryParams("city");
		        List<UserGG> users = new ArrayList<>();
		        UserGG user = new UserGG();
		        user.setUserId(userId);
		        user.setUserName(userName);
		        user.setRole(role);
		        user.setPassword(password);
		        user.setEmail(email);
		        user.setBday(bday);
		        user.setStreet(street);
		        user.setPcode(pcode);
		        user.setCity(city);
		        userDao.update(user);
		        users.add(user);
		        return gson.toJson(users);
		}); // end of updateUser	

//	getResponse Routes

		get("/usersAll", (req, res) -> {
			Gson gson = new Gson();
			List<UserGG> users = userDao.queryForAll();
			return gson.toJson(users);

		}); // end usersALL
		

		get("/hardwareAll", (req, res) -> {
			Gson gson = new Gson();
			List<Hardware> hardware = hardwareDao.queryForAll();
			return gson.toJson(hardware);

		}); // end hardwareALL

		get("/softwareAll", (req, res) -> {
			Gson gson = new Gson();
			List<Software> users = softwareDao.queryForAll();
			return gson.toJson(users);
		}); // end softwareALL

		get("/sales", (req, res) -> {
			Gson gson = new Gson();
			List<Object> sales = new ArrayList<Object>();
			List<Hardware> hardwareForSales = hardwareDao.queryForAll();
			List<Software> softwareForSales = softwareDao.queryForAll();
			for (Hardware h : hardwareForSales) {
				if (h.getSaleInPercent() > 0)
					sales.add(h);
			}
			for (Software s : softwareForSales) {
				if (s.getSaleInPercent() > 0)
					sales.add(s);
			}
			return gson.toJson(sales);
		}); // end sales

		get("/productsAll", (req, res) -> {
			System.out.println("Route: ProductAll activated");
			Gson gson = new Gson();
			List<Object> products = new ArrayList<Object>();
			List<Hardware> hardware = hardwareDao.queryForAll();
			List<Software> software = softwareDao.queryForAll();
			products.addAll(hardware);
			products.addAll(software);
			return gson.toJson(products);
		}); // end product

		get("/hardwareById/:id", (req, res) -> {
			Gson gson = new Gson();
			Hardware hardware;
			hardware = hardwareDao.queryForId(req.params(":id"));
			if (hardware != null) {

				List<Hardware> HardwareSingle = new ArrayList<>();
				HardwareSingle.add(hardware);

				return gson.toJson(HardwareSingle);
			} else {
				res.status(404);
				return "Hardware not Found";
			}

		}); // end HardwareByID

		get("/softwareById/:id", (req, res) -> {
			Gson gson = new Gson();
			Software software;
			software = softwareDao.queryForId(req.params(":id"));
			if (software != null) {

				List<Software> SoftwareSingle = new ArrayList<>();
				SoftwareSingle.add(software);

				return gson.toJson(SoftwareSingle);
			} else {
				res.status(404);
				return "Software not Found";
			}

		}); // end SoftwareByID

		get("/userById/:id", (req, res) -> {
			Gson gson = new Gson();
			UserGG user;
			user = userDao.queryForId(req.params(":id"));
			if (user != null) {

				List<UserGG> userSingle = new ArrayList<>();
				userSingle.add(user);

				return gson.toJson(userSingle);
			} else {
				res.status(404);
				return "User not Found";
			}

		}); // end UserByID
		
		get("/min/:rating", (req, res) -> {
			Gson gson = new Gson();
			double rating = Double.parseDouble(req.params(":rating"));
			List<Hardware> hardwares = hardwareDao.queryForAll();
			Hardware cpu = new Hardware();
			cpu.setRating(10000);
			Hardware gpu = new Hardware();
			gpu.setRating(10000);
			Hardware ram = new Hardware();
			ram.setRating(10000);
			for (Hardware h : hardwares) {
				if (h.getRating() < rating) {
					switch(h.getType()){
			        case "CPU":
			            if (h.getRating()<cpu.getRating())
			            	cpu=h;
			            break;
			        case "GPU":
			        	if (h.getRating()<gpu.getRating())
			            	gpu=h;
			            break;
			        case "RAM":
			        	if (h.getRating()<ram.getRating())
			            	ram=h;
			            break;
			        }//endSwitch
				} //endIF
				
			}//endFor
			hardwares.clear();
			hardwares.add(cpu);
			hardwares.add(gpu);
			hardwares.add(ram);
			return gson.toJson(hardwares);
		}); // end min
		
		get("/rec/:rating", (req, res) -> {
			Gson gson = new Gson();
			double rating = Double.parseDouble(req.params(":rating"));
			List<Hardware> hardwares = hardwareDao.queryForAll();
			Hardware cpu = new Hardware();
			cpu.setRating(100000);
			Hardware gpu = new Hardware();
			gpu.setRating(100000);
			Hardware ram = new Hardware();
			ram.setRating(100000);
			for (Hardware h : hardwares) {
				if (rating < h.getRating()) {
					switch(h.getType()){
			        case "CPU":
			            if ((h.getRating()<gpu.getRating()))
			            	cpu=h;
			            break;
			        case "GPU":
			        		if ((h.getRating()<gpu.getRating()) && (h.getRating() > (rating+100)) )
				            	gpu=h;
				            break;   
			        case "RAM":
			        	if ((h.getRating()<gpu.getRating()))
			            	ram=h;
			            break;
			        }//endSwitch
				} //endIF
			}//endFor
			hardwares.clear();
			hardwares.add(cpu);
			hardwares.add(gpu);
			hardwares.add(ram);
			return gson.toJson(hardwares);
		}); // end min
		

	} // end Main

} // end Class
